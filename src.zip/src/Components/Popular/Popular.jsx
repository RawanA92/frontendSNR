// Popular.jsx

import React, { useState } from "react";
import './Popular.css';
import data_product from '../Assests/data';
import Item from '../Item/Item';
import Cart from "../../Pages/Cart";
const Popular = () => {
  const [cartCount, setCartCount] = useState(0);

  const handleAddToCart = () => {
    setCartCount(cartCount + 1);
  };

  return (
    <div className='popular'>
      <h1>POPULAR PRODUCT</h1>
      <hr />
      <div className="popular-item">
        {data_product.map((item, i) => (
          <div key={i}>
            <Item id={item.id} name={item.name} image={item.image} new_price={item.new_price} old_price={item.old_price} />
            <Cart onAddToCart={handleAddToCart} count={cartCount} />
          </div>
        ))}
      </div>
    </div>
  );
};

export default Popular;
