import p1_img from './product_16.jpg'
import p2_img from './product_39.jpg'
import p3_img from './product_38.jpg'
import p4_img from './product_37.jpg'

let data_product = [
  {
    id:1,
    name:"Striped Flutter Sleeve Overlap Collar Peplum Hem Blouse",
    image:p1_img,
    new_price:5000.00,
    old_price:8000.50,
  },
  {id:2,
    name:"Striped Flutter Sleeve Overlap Collar Peplum Hem Blouse",
    image:p2_img,
    new_price:8500.00,
    old_price:12000.50,
  },
  {id:3,
    name:"Striped Flutter Sleeve Overlap Collar Peplum Hem Blouse",
    image:p3_img,
    new_price:6000.00,
    old_price:10000.50,
  },
  {id:4,
    name:"Striped Flutter Sleeve Overlap Collar Peplum Hem Blouse",
    image:p4_img,
    new_price:10000.00,
    old_price:15000.00,
  },
];

export default data_product;
