import p1_img from './product_16.jpg'
import p2_img from './product_39.jpg'
import p3_img from './product_38.jpg'
import p4_img from './product_90.jpg'

let data_product = [
  {
    id:1,
    name:"Robot Vacuum and Mop Combo, 4500Pa Suction, 150Mins Max, Robotic Vacuum Cleaner with Self-Charging, Quiet, APP&Voice Control, Ideal for Carpet, Hard Floor",
    image:p1_img,
    new_price:5000.00,
    old_price:8000.50,
  },
  {id:2,
    name:"Striped Flutter Sleeve Overlap Collar Peplum Hem Automatic Motion Sensor Night Light 360° Rotating LED Wall Lamp USB Rechargeable",
    image:p2_img,
    new_price:8500.00,
    old_price:12000.50,
  },
  {id:3,
    name:"Smart Plug, Smart Home WiFi Outlet Compatible with Alexa & Google Home, Alexa Smart Socket with Remote Control & Timer Function, 2.4GHz WiFi ",
    image:p3_img,
    new_price:6000.00,
    old_price:10000.50,
  },
  {id:4,
    name:"Striped Flutter Sleeve Overlap High Sensitivety 360°Automatic infrared Motion Sensor Switch led light Peplum Hem Blouse",
    image:p4_img,
    new_price:10000.00,
    old_price:15000.00,
  },
];

export default data_product;
