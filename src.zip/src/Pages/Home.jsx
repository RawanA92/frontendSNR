import React, { useState } from "react";
import Hero from "../Components/Hero/Hero";
import Popular from '../Components/Popular/Popular';
import Search from "../Components/Search/Search";

const Home = () => {
  const [searchQuery, setSearchQuery] = useState("");

  const handleSearch = (query) => {
    // Handle the search logic here, e.g., filter products based on the query
    setSearchQuery(query);
    // Perform any other actions related to the search
    console.log(`Search for: ${query}`);
  };

  return (
    <div>
      <Search onSearch={handleSearch} />
      <Hero />
      <Popular />
    </div>
  );
};

export default Home;
